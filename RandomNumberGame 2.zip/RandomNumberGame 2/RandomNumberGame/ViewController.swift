//
//  ViewController.swift
//  RandomNumberGame
//
//  Created by user191025 on 6/24/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var totalScore: UILabel!
    @IBOutlet weak var randomNo: UILabel!
    
    @IBOutlet weak var tryOut: UIButton!
    var randomStore : Int = 1
    @IBAction func tryButton(_ sender: UIButton) {
        
        checkOut.isEnabled = true
        let randomN = Int.random(in: 0...100)
        randomNo.text = String(randomN)
        randomStore = randomN
    }

    var sliderVal : Int = 0
    @IBOutlet weak var sliderOut: UISlider!
    @IBAction func slider(_ sender: UISlider) {
        sliderVal = Int(sliderOut.value)
        
    }
    
    @IBOutlet weak var checkOut: UIButton!
    var total : Int = 0
   
    @IBAction func checkButton(_ sender: UIButton) {
        
        if (randomStore == sliderVal)
        {
            total = total+1
            totalScore.text = String(total)
            checkOut.isEnabled = false
        }
    }
  
    @IBAction func Reset() {
            
        total = 0
        totalScore.text = "Total Score"
        randomStore = 1
        randomNo.text = "Random Number"
        sliderOut.value = 0
        checkOut.isEnabled = true
    }
}
